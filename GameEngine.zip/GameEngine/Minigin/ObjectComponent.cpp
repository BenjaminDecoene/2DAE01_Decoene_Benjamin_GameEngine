#include "MiniginPCH.h"
#include "ObjectComponent.h"

ObjectComponent::ObjectComponent(const std::string& type)
	:m_Type(type)
{
}
